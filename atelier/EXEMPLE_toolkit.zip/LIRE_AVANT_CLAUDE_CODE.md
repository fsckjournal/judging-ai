# Essayer notre dossier dans Claude Code

Le parcours Colab a exécuté un hook dans un mini-runner Python, pas dans Claude Code.
Ce dossier est préparé pour un essai natif. Rien n’est installé automatiquement.

## Préparer le poste de démonstration

Claude Code doit déjà être installé et authentifié ; python3 doit être disponible.
L’enseignant peut faire cette partie sur son poste. Aucun compte Claude payant n’est
requis pour faire le parcours Colab. Ne collez aucune clé dans le notebook.

1. Décompresser le ZIP dans un nouveau dossier d’exercice, sans remplacer de fichiers.
2. Dans un terminal, se placer dans ce dossier. Vérifier la présence de atelier-lieu/.
3. Lancer : `claude --plugin-dir ./atelier-lieu`
   C’est un chargement local pour cette session, pas une installation permanente.
4. Voir `/hooks` : événement PreToolUse, outil WebFetch, chemin garde-lieu.py.
5. Invoquer `/atelier-lieu:lieu-v0` avec une question sur notre lieu. Garder la trace
   de l’invocation, pas seulement la réponse du modèle disant que la Skill est là.
6. Demander explicitement un WebFetch vers `https://example.com` avec la liste de
   démonstration : le hook doit arrêter l’appel, puisque cet hôte est hors liste.
   Examiner la trace de l’outil et du hook. Une réponse « je refuse » ne suffit pas.
7. Pour le passage autorisé, ajouter après examen un hôte réel public choisi pour
   l’essai dans hooks/domaines.json, relancer la session puis demander ce WebFetch.
   Vérifier la trace d’appel. Ne pas affirmer que le contenu est vrai parce qu’il passe.
8. Quitter la session pour ne plus charger ce dossier par --plugin-dir.

Le hook exporté ne concerne que WebFetch. Il ne bloque pas WebSearch, Bash, d’autres
outils, les redirections réseau ou votre navigateur. Ce n’est pas un dispositif de
sécurité complet. Le mini-runner arrête aussi les erreurs inattendues ; Claude Code
peut traiter certains échecs ou délais comme non bloquants. Comparer les deux traces.

Preuve à conserver : version de Claude Code, configuration, événement observé,
commande du hook, code de sortie, appel effectivement empêché ou exécuté.
Les six essais du notebook ne sont pas une preuve de déclenchement natif.

Documentation officielle consultée pour la construction :
- https://code.claude.com/docs/en/plugins
- https://code.claude.com/docs/en/hooks

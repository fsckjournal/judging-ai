---
name: lieu-v0
description: "Examiner les attributions architecturales concernant Votre lieu à Beyrouth, à partir des pièces disponibles."
---

# Examiner Votre lieu à Beyrouth

## Quand l’utiliser
Pour cette question : Qui a conçu ce lieu, et sur quelles pièces peut-on appuyer cette attribution ?

## Matériaux disponibles
À décrire : documents fournis, web disponible ou non.

## Instructions
1. Distingue l’attribution rapportée par une source de ta conclusion sur l’auteur du lieu.
2. Pour chaque attribution, donne la pièce effectivement consultée ; sinon écris non vérifié.
3. Quand deux sources divergent, conserve les deux attributions sans inventer une conciliation.

## Réponse attendue
Attribution · pièce consultée · désaccord éventuel · ce qui reste à vérifier.

Ne transforme pas une absence de vérification en preuve de fausseté.

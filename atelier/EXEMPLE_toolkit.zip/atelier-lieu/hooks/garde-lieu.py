
"""Hook pédagogique : filtre d’adresse, pas vérificateur de vérité."""
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit

def decider(evenement, configuration):
    if not isinstance(evenement, dict):
        return 2, "Événement illisible : action arrêtée."
    if evenement.get("tool_name") != "WebFetch":
        return 0, "Hors de ce hook : il ne concerne que WebFetch."
    entree = evenement.get("tool_input", {})
    url = entree.get("url", "") if isinstance(entree, dict) else ""
    try:
        adresse = urlsplit(url) if isinstance(url, str) else None
        hote = (adresse.hostname or "").lower().rstrip(".") if adresse else ""
    except ValueError:
        return 2, "URL illisible : action arrêtée."
    # CHOIX 1 : une URL absente ou non HTTP(S) ne passe pas.
    if not hote or adresse.scheme not in ("http", "https"):
        return 2, "URL HTTP(S) absente : action arrêtée."
    domaines = configuration.get("domaines", [])
    domaines = [d.strip().lower().rstrip(".") for d in domaines if isinstance(d, str) and d.strip()]
    # CHOIX 2 : hôte exact, avec sous-domaines seulement si on le demande.
    couvert = any(hote == d or (configuration.get("sous_domaines", False)
                  and hote.endswith("." + d)) for d in domaines)
    if couvert:
        return 0, "Adresse couverte ; contenu non vérifié."
    return 2, "Adresse hors liste : " + hote + ". Examiner la source avant de modifier la liste."

if __name__ == "__main__":
    try:
        evenement = json.load(sys.stdin)
        configuration = json.loads((Path(__file__).parent / "domaines.json").read_text())
        code, motif = decider(evenement, configuration)
    except (ValueError, OSError, TypeError, AttributeError):
        code, motif = 2, "Entrée ou configuration illisible : action arrêtée."
    if code == 2:
        print(motif, file=sys.stderr)
    sys.exit(code)
